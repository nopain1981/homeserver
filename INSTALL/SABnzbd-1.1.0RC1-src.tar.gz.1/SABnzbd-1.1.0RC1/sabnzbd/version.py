# This file will be patched by setup.py
# The __version__ should be set to the branch name
# (e.g. "trunk" or "0.4.x")

# You MUST use double quotes (so " and not ')

__version__ = "1.1.0RC1"
__baseline__ = "aa12e2190fd45ac6700e03a04e01f4f06c6a4daf"
