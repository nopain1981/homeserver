#!/usr/bin/env bash
docker build --rm -t timhaak/plexpass .
