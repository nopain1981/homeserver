#!/usr/bin/env bash
docker build --rm --pull --no-cache -t timhaak/plexpass .
